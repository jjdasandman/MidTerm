<?php
ob_start();
require("authors.csv");
require("quotes.csv");
$data = ob_get_clean();
require("functions.php");



$qi = $_GET["index"]; //quote index

$qai = array(); //qoutes, arthors index

$handle = fopen("quotes.csv", "r");
//$handle2 = fopen("authors.csv", "r");
while(list($index,$quote,$ai) =fgetcsv($handle,2024,',')) {
	if( trim($index)!='' && trim($quote)!='') {
		$qai[] = ['index'=>clean_text($index), 'quote'=>clean_text($quote), 'authors_index'=>clean_text($ai)];
		//reading quotes and Ai and storing them into an array for access later
	}
	
	
	
}



?>
<h2><?php echo $qai[$qi]['quote'] ?></h2>
<h4><?php echo matchIndex($qai[$qi]['authors_index']) ?></h4>
<form action="modify.php">
    <input type="submit" value="modify" />
</form>
<form action="delete.php">
    <input type="submit" value="delete" />
</form>