<?php 
function clean_text($string){
	$string = trim($string);
	$string = stripslashes($string);
	$string = htmlspecialchars($string);
	return $string;
}
function cleanText($string){
	$string = trim($string);
	$string = stripslashes($string);
	$string = htmlspecialchars($string);
	return $string;
}
function matchIndex($ai) {
	//matches given index on quote to index of author
	$author;
	$handle = fopen("authors.csv", "r");
	while(list($index,$first,$last) =fgetcsv($handle,2024,',')  ) {
		if($ai == $index){
			return $first.' '.$last;
		}
		
	}
	fclose($handle);
	return 'anon';
	
}
function displayQuote($array, $index) {
	$quote = $array[$index]['quote'];
	$author = matchIndex($array[$index]['authors_index']);
	if(empty($quote) == true){
		return;
	}
	?>
	<a href="details.php?index=<?php echo $index ?>"><h3><?php echo $array[$index]['quote'] ?></h3></a>
	<h4><?php echo matchIndex($array[$index]['authors_index']) ?></h4>
	<?php
	echo '<hr />';
}

?>