<?php
ob_start();
require("authors.csv");
require("quotes.csv");
$data = ob_get_clean();
//declare variables and functions

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}
function matchIndex($ai) {
	//matches given index on quote to index of author
	$author;
	$handle = fopen("authors.csv", "r");
	while(list($index,$first,$last) =fgetcsv($handle,2024,',')  ) {
		if($ai == $index){
			return $first.' '.$last;
		}
		
	}
	fclose($handle);
	return 'anon';
	
}
function displayQuote($array, $index) {
	$quote = $array[$index]['quote'];
	$author = matchIndex($array[$index]['authors_index']);
	if(empty($quote) == true){
		return;
	}
	?>
	<a href="details.php?index=<?php echo $index ?>"><h3><?php echo $array[$index]['quote'] ?></h3></a>
	<h4><?php echo matchIndex($array[$index]['authors_index']) ?></h4>
	<?php
	echo '<hr />';
}


 
 


$qai = array(); //qoutes, arthors index

$handle = fopen("quotes.csv", "r");
//$handle2 = fopen("authors.csv", "r");
while(list($index,$quote,$ai) =fgetcsv($handle,2024,',')) {
	if( trim($index)!='' && trim($quote)!='') {
		$qai[] = ['index'=>clean_text($index), 'quote'=>clean_text($quote), 'authors_index'=>clean_text($ai)];
		//reading quotes and Ai and storing them into an array for access later
	}
	
	
}









?> 
<html lang="en">

<head>
	<title>ASE 230 - great quotes/index</title>
</head>
	
<body>

<?php
 for($i=1;$i<count($qai);$i++) {
	displayQuote($qai,$i);
}
?>

<a href="create.php">creat a quote!</a>



