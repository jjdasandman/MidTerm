<?php
ob_start();
require("authors.csv");
require("quotes.csv");
$data = ob_get_clean();


?>