<?php
ob_start();
require("authors.csv");
require("quotes.csv");
$data = ob_get_clean();


//echo '<hr />'

// *define variables here * //
$error = '';
$quote = '';
$num_lines = count(file('authors.csv')); //number of lines in file
$ai; //authors index
$nameErr = ''; //error message


//

//Define functions here//
function cleanText($string){
	//cleans texts of spaces, malicous content, etc
	$string = trim($string);
	$string = stripslashes($string);
	$string = htmlspecialchars($string);
	return $string;
}

function isValid() {
	//checks that there is something in the message box
	$uh = getElementById('message');

	$_POST['submit'];
	//event.preventDefault();
	/*if( isset($temp)==false){
		return false;
		//<button type="button" class="btn btn-default" onclick="javascript:history.go(-1)">Back</button>
	}
	else{
		return true;
	}*/
}
function submit(){
	$_POST['submit'];
}
?> 
<script type="text/javascript">
// prevents form from submitting to check is feilds are empty
    function submitForm(event){
        //event.preventDefault();
		//submit();
    }
</script>
<?php



//


//make array to store authors
$authors = array();

$handle = fopen("authors.csv", "r");
while(list($index,$first,$last) =fgetcsv($handle,2024,',')  ) {
	$authors[] = ['index'=>$index, 'first'=>$first, 'last'=>$last];

	//reading authors and storing them into an array for access later
	
	
}

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

$error = '';
$message = '';
//isset($_POST["submit"])
//$_SERVER["REQUEST_METHOD"] == "POST"

if($_SERVER["REQUEST_METHOD"] == "POST")
{

 if(empty($_POST["message"]))
 {
  $nameErr = "* message is required";
  ?><script type="text/javascript">
  event.preventDefault();
  </script>
  <?php
  //displays warning if no text present upon submitting
 }
 else
 {
  $message = clean_text($_POST["message"]); //strips text
  
 }
 //finding and saving authors index
 $ai = $_POST["authors"];

	
	
  $file_open = fopen("quotes.csv", "a");
  //find number of rows
  $no_rows = count(file("quotes.csv"));
  if($no_rows > 1) //if there is conent already in file
  {
   $no_rows = ($no_rows - 1) + 1; //append to next line to aviod overwriting
  }
  //find authors index
  $form_data = array(
   'sr_no'  => $no_rows, //index
   'message' => $message, //quote
   'authors_index' => $ai
   
   
  );


  fputcsv($file_open, $form_data); //put data into quotes.csv
  echo 'form submitted';
  $error = '<label class="text-success">Thank you for contacting us</label>';
  $message = '';
 
}

?> 
<!doctype html>


<html lang="en">

<head>
	<title>ASE 230 - great quotes/create</title>
</head>

<body>
<!-- onsubmit="event.preventDefault(), isValid()" -->
<form action="" method="post" onsubmit="submitForm(event)">

	<!-- <p>Quote: <input type="text" name="quote"></p> -->
	<p><label>Enter quote</label></p>
    <p><textarea name="message" class="form-control" placeholder="Enter quote"><?php echo $message; ?></textarea></p>
	<span class="error"> <?php echo $nameErr;?></span>
	<br><br>
	
	<label for="authors">Choose an author:</label>

	<select name="authors" id="authors">
	<?php 
	for($i = 0;$i<count($authors);$i++){
	echo '<option value="'.$authors[$i]['index'].'">'.$authors[$i]['first'].' '.$authors[$i]['last'].'</option>';
	//display authors
	}
	?>
	</select>



	<input type="submit" name="submit">
	<input type="reset" name="reset">
</form>